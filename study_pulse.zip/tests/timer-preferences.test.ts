import { describe, it, expect } from "vitest";

// Define types locally to avoid import issues in tests
type TimerPreferences = {
  focusDuration: number;
  breakDuration: number;
  notificationsEnabled: boolean;
};

const DEFAULT_TIMER_PREFERENCES: TimerPreferences = {
  focusDuration: 25,
  breakDuration: 5,
  notificationsEnabled: true,
};

const validateDuration = (duration: string): { valid: boolean; value: number; error?: string } => {
  const parsed = parseInt(duration, 10);
  if (isNaN(parsed)) {
    return { valid: false, value: 0, error: "Please enter a valid number" };
  }
  if (parsed < 1) {
    return { valid: false, value: 0, error: "Duration must be at least 1 minute" };
  }
  if (parsed > 120) {
    return { valid: false, value: 0, error: "Duration must not exceed 120 minutes" };
  }
  return { valid: true, value: parsed };
};

describe("Timer Preferences & Configuration", () => {
  describe("validateDuration", () => {
    it("should accept valid duration strings", () => {
      const result = validateDuration("25");
      expect(result.valid).toBe(true);
      expect(result.value).toBe(25);
      expect(result.error).toBeUndefined();
    });

    it("should accept minimum duration of 1 minute", () => {
      const result = validateDuration("1");
      expect(result.valid).toBe(true);
      expect(result.value).toBe(1);
    });

    it("should accept maximum duration of 120 minutes", () => {
      const result = validateDuration("120");
      expect(result.valid).toBe(true);
      expect(result.value).toBe(120);
    });

    it("should reject zero duration", () => {
      const result = validateDuration("0");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("at least 1 minute");
    });

    it("should reject negative duration", () => {
      const result = validateDuration("-5");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("at least 1 minute");
    });

    it("should reject duration exceeding 120 minutes", () => {
      const result = validateDuration("121");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("not exceed 120 minutes");
    });

    it("should reject non-numeric strings", () => {
      const result = validateDuration("abc");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("valid number");
    });

    it("should reject empty strings", () => {
      const result = validateDuration("");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("valid number");
    });
  });

  describe("DEFAULT_TIMER_PREFERENCES", () => {
    it("should have correct default focus duration", () => {
      expect(DEFAULT_TIMER_PREFERENCES.focusDuration).toBe(25);
    });

    it("should have correct default break duration", () => {
      expect(DEFAULT_TIMER_PREFERENCES.breakDuration).toBe(5);
    });

    it("should have notifications enabled by default", () => {
      expect(DEFAULT_TIMER_PREFERENCES.notificationsEnabled).toBe(true);
    });

    it("should be a valid TimerPreferences object", () => {
      const prefs: TimerPreferences = DEFAULT_TIMER_PREFERENCES;
      expect(prefs).toBeDefined();
      expect(typeof prefs.focusDuration).toBe("number");
      expect(typeof prefs.breakDuration).toBe("number");
      expect(typeof prefs.notificationsEnabled).toBe("boolean");
    });
  });

  describe("TimerPreferences type", () => {
    it("should create valid preferences with custom values", () => {
      const customPrefs: TimerPreferences = {
        focusDuration: 30,
        breakDuration: 10,
        notificationsEnabled: false,
      };

      expect(customPrefs.focusDuration).toBe(30);
      expect(customPrefs.breakDuration).toBe(10);
      expect(customPrefs.notificationsEnabled).toBe(false);
    });

    it("should allow toggling notifications", () => {
      const prefs: TimerPreferences = {
        ...DEFAULT_TIMER_PREFERENCES,
        notificationsEnabled: false,
      };

      expect(prefs.notificationsEnabled).toBe(false);

      const updatedPrefs: TimerPreferences = {
        ...prefs,
        notificationsEnabled: true,
      };

      expect(updatedPrefs.notificationsEnabled).toBe(true);
    });

    it("should allow updating durations independently", () => {
      const prefs: TimerPreferences = {
        ...DEFAULT_TIMER_PREFERENCES,
        focusDuration: 45,
      };

      expect(prefs.focusDuration).toBe(45);
      expect(prefs.breakDuration).toBe(5);
      expect(prefs.notificationsEnabled).toBe(true);
    });
  });

  describe("Timer preference validation edge cases", () => {
    it("should handle floating point numbers", () => {
      const result = validateDuration("25.5");
      // parseInt will parse to 25, which is valid
      expect(result.valid).toBe(true);
      expect(result.value).toBe(25);
    });

    it("should handle whitespace in input", () => {
      const result = validateDuration("  25  ");
      // parseInt handles leading/trailing whitespace
      expect(result.valid).toBe(true);
      expect(result.value).toBe(25);
    });

    it("should handle very large numbers", () => {
      const result = validateDuration("9999");
      expect(result.valid).toBe(false);
      expect(result.error).toContain("not exceed 120 minutes");
    });
  });

  describe("Preference persistence patterns", () => {
    it("should support serialization to JSON", () => {
      const prefs: TimerPreferences = DEFAULT_TIMER_PREFERENCES;
      const serialized = JSON.stringify(prefs);
      const deserialized = JSON.parse(serialized) as TimerPreferences;

      expect(deserialized.focusDuration).toBe(prefs.focusDuration);
      expect(deserialized.breakDuration).toBe(prefs.breakDuration);
      expect(deserialized.notificationsEnabled).toBe(prefs.notificationsEnabled);
    });

    it("should handle partial updates correctly", () => {
      const original: TimerPreferences = DEFAULT_TIMER_PREFERENCES;
      const updated: TimerPreferences = {
        ...original,
        focusDuration: 50,
      };

      expect(updated.focusDuration).toBe(50);
      expect(updated.breakDuration).toBe(original.breakDuration);
      expect(updated.notificationsEnabled).toBe(original.notificationsEnabled);
    });
  });
});
