import { useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, TextInput, FlatList } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

export default function SubjectsScreen() {
  const colors = useColors();
  const [subjects, setSubjects] = useState(["Mathematics", "Computer Science"]);
  const [inputValue, setInputValue] = useState("");

  const handleAddSubject = () => {
    if (inputValue.trim()) {
      setSubjects([...subjects, inputValue.trim()]);
      setInputValue("");
    }
  };

  const handleRemoveSubject = (index: number) => {
    setSubjects(subjects.filter((_, i) => i !== index));
  };

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <SafeAreaView edges={["top", "left", "right"]} className="flex-1">
        <ScrollView contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24, paddingTop: 16 }}>
          {/* Header */}
          <View className="mb-6">
            <Text className="text-3xl font-bold text-foreground mb-2">Subjects</Text>
            <Text className="text-sm text-muted">Manage your study topics</Text>
          </View>

          {/* Input Section */}
          <View className="mb-6 gap-3">
            <View
              className="flex-row items-center gap-2 rounded-lg px-4 py-3 border"
              style={{
                borderColor: colors.border,
                backgroundColor: colors.surface,
              }}
            >
              <TextInput
                className="flex-1 text-foreground"
                placeholder="Add a new subject..."
                placeholderTextColor={colors.muted}
                value={inputValue}
                onChangeText={setInputValue}
                onSubmitEditing={handleAddSubject}
                returnKeyType="done"
                style={{ color: colors.foreground }}
              />
            </View>

            <TouchableOpacity
              onPress={handleAddSubject}
              disabled={!inputValue.trim()}
              className="py-3 rounded-lg items-center"
              style={{
                backgroundColor: colors.primary,
                opacity: inputValue.trim() ? 1 : 0.5,
              }}
            >
              <Text className="text-base font-semibold text-background">Add Subject</Text>
            </TouchableOpacity>
          </View>

          {/* Subjects List */}
          <View className="flex-1">
            {subjects.length === 0 ? (
              <View className="flex-1 justify-center items-center">
                <Text className="text-base text-muted text-center">
                  No subjects yet. Add one to get started!
                </Text>
              </View>
            ) : (
              <FlatList
                data={subjects}
                keyExtractor={(_, index) => index.toString()}
                scrollEnabled={false}
                renderItem={({ item, index }) => (
                  <View
                    className="rounded-xl p-4 mb-3 flex-row justify-between items-center"
                    style={{ backgroundColor: colors.surface }}
                  >
                    <Text className="text-base font-semibold text-foreground flex-1">
                      {item}
                    </Text>
                    <TouchableOpacity
                      onPress={() => handleRemoveSubject(index)}
                      className="px-3 py-2 rounded-lg"
                      style={{ backgroundColor: colors.error }}
                    >
                      <Text className="text-xs font-semibold text-background">Remove</Text>
                    </TouchableOpacity>
                  </View>
                )}
              />
            )}
          </View>
        </ScrollView>
      </SafeAreaView>
    </ScreenContainer>
  );
}
