import { useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, Modal } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenContainer } from "@/components/screen-container";
import { TimerConfigPanel } from "@/components/timer-config-panel";
import { useTimer, formatTime } from "@/hooks/use-timer";
import { useColors } from "@/hooks/use-colors";

export default function TimerScreen() {
  const colors = useColors();
  const { state, dispatch, updatePreferences, toggleNotifications } = useTimer();
  const [showNotification, setShowNotification] = useState(false);
  const [showConfigPanel, setShowConfigPanel] = useState(false);

  // Show notification when session completes
  if (state.sessionComplete && !showNotification) {
    setShowNotification(true);
  }

  const handleDismissNotification = () => {
    setShowNotification(false);
    dispatch({ type: "DISMISS_NOTIFICATION" });
  };

  const handleApplyChanges = async (focusDuration: number, breakDuration: number) => {
    await updatePreferences(focusDuration, breakDuration, state.notificationsEnabled);
    setShowConfigPanel(false);
  };

  const modeLabel = state.mode === "focus" ? "Focus Time" : "Break Time";
  const buttonColor = state.isRunning ? colors.error : colors.success;
  const buttonLabel = state.isRunning ? "Pause" : "Start";

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <SafeAreaView edges={["top", "left", "right"]} className="flex-1">
        <ScrollView contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 24, paddingBottom: 24, paddingTop: 16 }}>
          <View className="w-full items-center gap-6">
            {/* Mode Label */}
            <View>
              <Text className="text-lg font-semibold text-muted text-center">{modeLabel}</Text>
            </View>

            {/* Timer Display */}
            <View
              className="w-full max-w-xs aspect-square rounded-3xl items-center justify-center"
              style={{ backgroundColor: colors.surface }}
            >
              <Text
                className="font-mono text-9xl font-bold"
                style={{ color: colors.primary, fontFamily: "monospace" }}
              >
                {formatTime(state.timeLeft)}
              </Text>
            </View>

            {/* Control Buttons */}
            <View className="w-full max-w-xs gap-4">
              {/* Start/Pause Button */}
              <TouchableOpacity
                onPress={() => dispatch({ type: state.isRunning ? "PAUSE" : "START" })}
                className="w-full py-4 rounded-lg items-center"
                style={{ backgroundColor: buttonColor }}
              >
                <Text className="text-lg font-semibold text-background">{buttonLabel}</Text>
              </TouchableOpacity>

              {/* Reset Button */}
              <TouchableOpacity
                onPress={() => dispatch({ type: "RESET" })}
                className="w-full py-3 rounded-lg items-center border"
                style={{ borderColor: colors.border, backgroundColor: colors.surface }}
              >
                <Text className="text-base font-semibold text-foreground">Reset</Text>
              </TouchableOpacity>

              {/* Toggle Mode Button */}
              <TouchableOpacity
                onPress={() => dispatch({ type: "TOGGLE_MODE" })}
                className="w-full py-3 rounded-lg items-center border"
                style={{ borderColor: colors.secondary, backgroundColor: colors.surface }}
              >
                <Text className="text-base font-semibold" style={{ color: colors.secondary }}>
                  {state.mode === "focus" ? "Switch to Break" : "Switch to Focus"}
                </Text>
              </TouchableOpacity>

              {/* Configuration Button */}
              <TouchableOpacity
                onPress={() => setShowConfigPanel(!showConfigPanel)}
                className="w-full py-3 rounded-lg items-center border"
                style={{ borderColor: colors.primary, backgroundColor: colors.surface }}
              >
                <Text className="text-base font-semibold" style={{ color: colors.primary }}>
                  {showConfigPanel ? "Hide Settings" : "⚙️ Settings"}
                </Text>
              </TouchableOpacity>
            </View>

            {/* Progress Info */}
            <View className="items-center gap-1">
              <Text className="text-sm text-muted">
                {state.isRunning ? "Running..." : "Paused"}
              </Text>
            </View>

            {/* Configuration Panel */}
            {showConfigPanel && (
              <View className="w-full max-w-xs">
                <TimerConfigPanel
                  focusDuration={state.focusDuration}
                  breakDuration={state.breakDuration}
                  notificationsEnabled={state.notificationsEnabled}
                  onApplyChanges={handleApplyChanges}
                  onToggleNotifications={toggleNotifications}
                />
              </View>
            )}
          </View>
        </ScrollView>

        {/* Notification Modal */}
        <Modal
          visible={showNotification}
          transparent
          animationType="fade"
          onRequestClose={handleDismissNotification}
        >
          <View
            className="flex-1 justify-center items-center px-4"
            style={{ backgroundColor: "rgba(0, 0, 0, 0.5)" }}
          >
            <View
              className="w-full max-w-sm rounded-2xl p-6 gap-4"
              style={{ backgroundColor: colors.surface }}
            >
              <Text className="text-2xl font-bold text-foreground text-center">
                {state.mode === "focus" ? "Focus Session Complete!" : "Break Time Over!"}
              </Text>
              <Text className="text-base text-muted text-center">
                {state.mode === "focus"
                  ? "Great work! Time to take a break."
                  : "Ready to focus again? Let's go!"}
              </Text>
              <TouchableOpacity
                onPress={handleDismissNotification}
                className="w-full py-3 rounded-lg items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-base font-semibold text-background">Continue</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </SafeAreaView>
    </ScreenContainer>
  );
}
