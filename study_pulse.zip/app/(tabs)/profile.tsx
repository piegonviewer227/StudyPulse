import { ScrollView, Text, View, TouchableOpacity, Switch } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useRouter } from "expo-router";
import { useAuth } from "@/lib/auth-context";
import { useSetColorScheme } from "@/lib/theme-provider";

export default function ProfileScreen() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const router = useRouter();
  const { dispatch } = useAuth();
  const setColorScheme = useSetColorScheme();

  const handleToggleTheme = () => {
    const newScheme = colorScheme === "light" ? "dark" : "light";
    setColorScheme(newScheme);
  };

  const handleLogout = () => {
    dispatch({ type: "LOGOUT" });
    router.replace("/login");
  };

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <SafeAreaView edges={["top", "left", "right"]} className="flex-1">
        <ScrollView contentContainerStyle={{ paddingHorizontal: 24, gap: 24, paddingBottom: 20, paddingTop: 16 }}>
          {/* Header */}
          <View className="mb-4">
            <Text className="text-3xl font-bold text-foreground mb-2">Profile</Text>
            <Text className="text-sm text-muted">Your account settings</Text>
          </View>

          {/* User Info Card */}
          <View
            className="rounded-2xl p-6 gap-4"
            style={{ backgroundColor: colors.surface }}
          >
            {/* Avatar */}
            <View className="items-center">
              <View
                className="w-20 h-20 rounded-full items-center justify-center"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-4xl font-bold text-background">A</Text>
              </View>
            </View>

            {/* User Details */}
            <View className="items-center gap-1">
              <Text className="text-2xl font-bold text-foreground">Alex Learner</Text>
              <Text className="text-sm text-muted">alex@studypulse.com</Text>
            </View>

            {/* User Stats */}
            <View className="flex-row justify-around gap-4 pt-4 border-t" style={{ borderTopColor: colors.border }}>
              <View className="items-center">
                <Text className="text-lg font-bold text-primary">42.5</Text>
                <Text className="text-xs text-muted">Study Hours</Text>
              </View>
              <View className="items-center">
                <Text className="text-lg font-bold text-primary">127</Text>
                <Text className="text-xs text-muted">Sessions</Text>
              </View>
              <View className="items-center">
                <Text className="text-lg font-bold text-primary">15</Text>
                <Text className="text-xs text-muted">Days Streak</Text>
              </View>
            </View>
          </View>

          {/* Settings Section */}
          <View className="gap-3">
            <Text className="text-lg font-semibold text-foreground mb-2">Settings</Text>

            {/* Theme Toggle */}
            <TouchableOpacity
              onPress={handleToggleTheme}
              className="rounded-xl p-4 flex-row justify-between items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">Theme</Text>
                <Text className="text-xs text-muted">
                  Current: {colorScheme === "light" ? "Light" : "Dark"}
                </Text>
              </View>
              <View
                className="px-4 py-2 rounded-lg"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-sm font-semibold text-background">
                  {colorScheme === "light" ? "🌙 Dark" : "☀️ Light"}
                </Text>
              </View>
            </TouchableOpacity>
            {/* Notifications (Placeholder) */}
            <View
              className="rounded-xl p-4 flex-row justify-between items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">Notifications</Text>
                <Text className="text-xs text-muted">Enabled</Text>
              </View>
              <View
                className="w-12 h-7 rounded-full items-center justify-end flex-row pr-1"
                style={{ backgroundColor: colors.success }}
              >
                <View
                  className="w-5 h-5 rounded-full"
                  style={{ backgroundColor: colors.background }}
                />
              </View>
            </View>

            {/* Focus Duration (Placeholder) */}
            <View
              className="rounded-xl p-4 flex-row justify-between items-center"
              style={{ backgroundColor: colors.surface }}
            >
              <View className="gap-1">
                <Text className="text-base font-semibold text-foreground">Focus Duration</Text>
                <Text className="text-xs text-muted">25 minutes</Text>
              </View>
              <Text className="text-base font-semibold text-primary">25m</Text>
            </View>
          </View>

          {/* Logout Button */}
          <TouchableOpacity
            onPress={handleLogout}
            className="py-4 rounded-lg items-center"
            style={{ backgroundColor: colors.error }}
          >
            <Text className="text-base font-semibold text-background">Log Out</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </ScreenContainer>
  );
}
