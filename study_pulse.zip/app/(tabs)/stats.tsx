import { useEffect, useState } from "react";
import { ScrollView, Text, View, TouchableOpacity, ActivityIndicator, FlatList } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { ScreenContainer } from "@/components/screen-container";
import { useAnalytics } from "@/hooks/use-analytics";
import { useColors } from "@/hooks/use-colors";

export default function StatsScreen() {
  const colors = useColors();
  const { state, loadAnalytics, retry } = useAnalytics();
  const [stateMode, setStateMode] = useState<"loading" | "error" | "success">("loading");

  // Load analytics on mount
  useEffect(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  // Update state mode based on analytics state
  useEffect(() => {
    if (state.status === "loading") {
      setStateMode("loading");
    } else if (state.status === "error") {
      setStateMode("error");
    } else if (state.status === "success") {
      setStateMode("success");
    }
  }, [state.status]);

  const handleToggleState = () => {
    if (stateMode === "loading") {
      setStateMode("error");
    } else if (stateMode === "error") {
      setStateMode("success");
    } else {
      setStateMode("loading");
    }
  };

  return (
    <ScreenContainer className="flex-1" edges={["top", "left", "right"]}>
      <SafeAreaView edges={["top", "left", "right"]} className="flex-1">
        <ScrollView contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24, paddingTop: 16 }}>
          {/* Header */}
          <View className="mb-6">
            <Text className="text-3xl font-bold text-foreground mb-2">Analytics</Text>
            <Text className="text-sm text-muted">Your study progress</Text>
          </View>

          {/* State Toggle Button (for demo) */}
          <TouchableOpacity
            onPress={handleToggleState}
            className="mb-4 py-2 px-3 rounded-lg items-center"
            style={{ backgroundColor: colors.surface }}
          >
            <Text className="text-xs text-muted">
              Demo: {stateMode === "loading" ? "Loading" : stateMode === "error" ? "Error" : "Success"}
            </Text>
          </TouchableOpacity>

          {/* Loading State */}
          {stateMode === "loading" && (
            <View className="flex-1 justify-center items-center">
              <ActivityIndicator size="large" color={colors.primary} />
              <Text className="text-base text-muted mt-4">Loading your analytics...</Text>
            </View>
          )}

          {/* Error State */}
          {stateMode === "error" && (
            <View className="flex-1 justify-center items-center gap-4">
              <View className="items-center gap-2">
                <Text className="text-lg font-semibold text-error">Failed to Load Analytics</Text>
                <Text className="text-sm text-muted text-center">
                  Network error. Please check your connection and try again.
                </Text>
              </View>
              <TouchableOpacity
                onPress={retry}
                className="px-6 py-3 rounded-lg"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-base font-semibold text-background">Retry</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Success State */}
          {stateMode === "success" && (
            <View>
              {/* Total Study Time Card */}
              <View
                className="rounded-2xl p-6 mb-6"
                style={{ backgroundColor: colors.surface }}
              >
                <Text className="text-sm text-muted mb-2">Total Study Time</Text>
                <Text className="text-4xl font-bold text-primary">
                  {state.totalStudyTime.toFixed(1)} hrs
                </Text>
                <Text className="text-xs text-muted mt-2">All-time cumulative</Text>
              </View>

              {/* Recent Sessions Header */}
              <View className="mt-2 mb-4">
                <Text className="text-lg font-semibold text-foreground">Recent Sessions</Text>
              </View>

              {/* Sessions List */}
              <FlatList
                data={state.sessions}
                keyExtractor={(item) => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View
                    className="rounded-xl p-4 mb-3 flex-row justify-between items-center"
                    style={{ backgroundColor: colors.surface }}
                  >
                    <View className="flex-1">
                      <Text className="text-base font-semibold text-foreground">
                        {item.subject}
                      </Text>
                      <Text className="text-xs text-muted mt-1">{item.date}</Text>
                    </View>
                    <View className="items-end">
                      <Text className="text-lg font-bold text-primary">{item.duration}</Text>
                      <Text className="text-xs text-muted">minutes</Text>
                    </View>
                  </View>
                )}
              />
            </View>
          )}
        </ScrollView>
      </SafeAreaView>
    </ScreenContainer>
  );
}
