import { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator } from "react-native";
import { useAuth } from "@/lib/auth-context";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useRouter } from "expo-router";

export default function LoginScreen() {
  const colors = useColors();
  const router = useRouter();
  const { dispatch } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    setError("");
    setIsLoading(true);

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Hardcoded credentials
    if (username === "student" && password === "password") {
      dispatch({
        type: "LOGIN_SUCCESS",
        payload: {
          username: "student",
          name: "Alex Learner",
          email: "alex@studypulse.com",
        },
      });
      setIsLoading(false);
      router.replace("/(tabs)");
    } else {
      setError("Invalid username or password");
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer
      className="flex-1 justify-center items-center px-6"
      edges={["top", "left", "right", "bottom"]}
    >
      <View className="w-full max-w-sm gap-8">
        {/* Title */}
        <View className="items-center gap-2">
          <Text className="text-5xl font-bold text-foreground">StudyPulse</Text>
          <Text className="text-sm text-muted">Focus. Track. Succeed.</Text>
        </View>

        {/* Form */}
        <View className="gap-4">
          {/* Username Input */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">Username</Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="student"
              placeholderTextColor={colors.muted}
              value={username}
              onChangeText={setUsername}
              editable={!isLoading}
              style={{
                color: colors.foreground,
                borderColor: colors.border,
                backgroundColor: colors.surface,
              }}
            />
          </View>

          {/* Password Input */}
          <View>
            <Text className="text-sm font-semibold text-foreground mb-2">Password</Text>
            <TextInput
              className="border border-border rounded-lg px-4 py-3 text-foreground bg-surface"
              placeholder="password"
              placeholderTextColor={colors.muted}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!isLoading}
              style={{
                color: colors.foreground,
                borderColor: colors.border,
                backgroundColor: colors.surface,
              }}
            />
          </View>

          {/* Error Message */}
          {error ? <Text className="text-sm text-error text-center">{error}</Text> : null}

          {/* Login Button */}
          <TouchableOpacity
            onPress={handleLogin}
            disabled={isLoading}
            className="bg-primary rounded-lg py-3 items-center justify-center mt-2"
            style={{
              backgroundColor: colors.primary,
              opacity: isLoading ? 0.7 : 1,
            }}
          >
            {isLoading ? (
              <ActivityIndicator color={colors.background} size="small" />
            ) : (
              <Text className="text-lg font-semibold text-background">Log In</Text>
            )}
          </TouchableOpacity>
        </View>

        {/* Hint */}
        <View className="items-center">
          <Text className="text-xs text-muted text-center">
            Demo credentials: student / password
          </Text>
        </View>
      </View>
    </ScreenContainer>
  );
}
