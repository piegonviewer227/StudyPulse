/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

/**
 * Timer Configuration & Preferences Types
 */

export interface TimerPreferences {
  focusDuration: number; // in minutes
  breakDuration: number; // in minutes
  notificationsEnabled: boolean;
}

export interface TimerConfig {
  focusDurationSeconds: number; // in seconds
  breakDurationSeconds: number; // in seconds
  notificationsEnabled: boolean;
}

export type TimerConfigAction =
  | { type: "SET_FOCUS_DURATION"; payload: number } // in minutes
  | { type: "SET_BREAK_DURATION"; payload: number } // in minutes
  | { type: "SET_NOTIFICATIONS_ENABLED"; payload: boolean }
  | { type: "APPLY_CONFIG"; payload: Partial<TimerPreferences> }
  | { type: "RESET_TO_DEFAULTS" };

export const DEFAULT_TIMER_PREFERENCES: TimerPreferences = {
  focusDuration: 25, // minutes
  breakDuration: 5, // minutes
  notificationsEnabled: true,
};

/**
 * Timer State & Actions
 */

export type TimerMode = "focus" | "break";

export interface TimerState {
  mode: TimerMode;
  timeLeft: number; // in seconds
  isRunning: boolean;
  sessionComplete: boolean;
  focusDuration: number; // in minutes
  breakDuration: number; // in minutes
  notificationsEnabled: boolean;
}

export type TimerAction =
  | { type: "START" }
  | { type: "PAUSE" }
  | { type: "RESET" }
  | { type: "TOGGLE_MODE" }
  | { type: "DISMISS_NOTIFICATION" }
  | { type: "SET_DURATIONS"; payload: { focusDuration: number; breakDuration: number } }
  | { type: "TOGGLE_NOTIFICATIONS" }
  | { type: "LOAD_PREFERENCES"; payload: TimerPreferences };

/**
 * Timer Configuration Panel State
 */

export interface TimerConfigPanelState {
  focusInput: string;
  breakInput: string;
  isLoading: boolean;
  error: string | null;
}

/**
 * Notification Settings
 */

export interface NotificationSettings {
  enabled: boolean;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
}

/**
 * Validation Utilities
 */

export const validateDuration = (
  duration: string
): { valid: boolean; value: number; error?: string } => {
  const parsed = parseInt(duration, 10);
  if (isNaN(parsed)) {
    return { valid: false, value: 0, error: "Please enter a valid number" };
  }
  if (parsed < 1) {
    return { valid: false, value: 0, error: "Duration must be at least 1 minute" };
  }
  if (parsed > 120) {
    return { valid: false, value: 0, error: "Duration must not exceed 120 minutes" };
  }
  return { valid: true, value: parsed };
};

/**
 * Session & Analytics Types
 */

export interface Session {
  id: string;
  subject: string;
  date: string;
  duration: number; // in minutes
}

export interface AnalyticsState {
  totalStudyTime: number; // in hours
  sessions: Session[];
}

/**
 * Authentication Types
 */

export interface AuthState {
  isAuthenticated: boolean;
  username: string | null;
}

export type AuthAction =
  | { type: "LOGIN"; payload: { username: string } }
  | { type: "LOGOUT" };
