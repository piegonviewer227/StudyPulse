/** @type {const} */
const themeColors = {
  primary: { light: '#4A90E2', dark: '#6BA3F3' },
  secondary: { light: '#F5A623', dark: '#F7BC45' },
  background: { light: '#FFFFFF', dark: '#121212' },
  surface: { light: '#F0F0F5', dark: '#1E1E1E' },
  foreground: { light: '#1A1A1A', dark: '#E0E0E0' },
  muted: { light: '#6E6E6E', dark: '#A0A0A0' },
  border: { light: '#E0E0E0', dark: '#333333' },
  success: { light: '#388E3C', dark: '#66BB6A' },
  error: { light: '#D32F2F', dark: '#EF5350' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
};

module.exports = { themeColors };
