import { useEffect, useState } from "react";
import { useColorScheme as useRNColorScheme } from "react-native";
import { useThemeContext } from "@/lib/theme-provider";

/**
 * To support static rendering, this value needs to be re-calculated on the client side for web.
 * On web, this hook respects the app's theme context (from ThemeProvider).
 * On native, it returns the system color scheme.
 */
export function useColorScheme() {
  const [hasHydrated, setHasHydrated] = useState(false);
  const themeContext = useThemeContext();

  useEffect(() => {
    setHasHydrated(true);
  }, []);

  const systemColorScheme = useRNColorScheme();

  // On web, use the app's theme context
  // On native, use the system color scheme
  if (hasHydrated && typeof document !== "undefined") {
    return themeContext.colorScheme;
  }

  return systemColorScheme ?? "light";
}
