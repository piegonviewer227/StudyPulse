import { useReducer, useEffect, useCallback } from "react";
import { TimerPreferences, DEFAULT_TIMER_PREFERENCES } from "@/shared/types";
import { getTimerPreferences, setTimerPreferences } from "@/lib/_core/timer-preferences";

export type TimerMode = "focus" | "break";

export interface TimerState {
  mode: TimerMode;
  timeLeft: number; // in seconds
  isRunning: boolean;
  totalTime: number; // in seconds
  sessionComplete: boolean;
  focusDuration: number; // in minutes
  breakDuration: number; // in minutes
  notificationsEnabled: boolean;
}

export type TimerAction =
  | { type: "START" }
  | { type: "PAUSE" }
  | { type: "RESET" }
  | { type: "TOGGLE_MODE" }
  | { type: "TICK" }
  | { type: "COMPLETE" }
  | { type: "DISMISS_NOTIFICATION" }
  | { type: "SET_DURATIONS"; payload: { focusDuration: number; breakDuration: number } }
  | { type: "TOGGLE_NOTIFICATIONS" }
  | { type: "LOAD_PREFERENCES"; payload: TimerPreferences };

function getInitialTime(mode: TimerMode, focusDuration: number, breakDuration: number): number {
  return mode === "focus" ? focusDuration * 60 : breakDuration * 60;
}

function createInitialState(preferences: TimerPreferences): TimerState {
  const focusSeconds = preferences.focusDuration * 60;
  return {
    mode: "focus",
    timeLeft: focusSeconds,
    isRunning: false,
    totalTime: focusSeconds,
    sessionComplete: false,
    focusDuration: preferences.focusDuration,
    breakDuration: preferences.breakDuration,
    notificationsEnabled: preferences.notificationsEnabled,
  };
}

function timerReducer(state: TimerState, action: TimerAction): TimerState {
  switch (action.type) {
    case "START":
      return { ...state, isRunning: true };

    case "PAUSE":
      return { ...state, isRunning: false };

    case "RESET":
      const resetTime = getInitialTime(state.mode, state.focusDuration, state.breakDuration);
      return {
        ...state,
        isRunning: false,
        timeLeft: resetTime,
        totalTime: resetTime,
        sessionComplete: false,
      };

    case "TOGGLE_MODE":
      const newMode = state.mode === "focus" ? "break" : "focus";
      const newTime = getInitialTime(newMode, state.focusDuration, state.breakDuration);
      return {
        ...state,
        mode: newMode,
        timeLeft: newTime,
        totalTime: newTime,
        isRunning: false,
        sessionComplete: false,
      };

    case "TICK":
      if (!state.isRunning) return state;
      const newTimeLeft = state.timeLeft - 1;
      if (newTimeLeft <= 0) {
        return {
          ...state,
          timeLeft: 0,
          isRunning: false,
          sessionComplete: true,
        };
      }
      return { ...state, timeLeft: newTimeLeft };

    case "COMPLETE":
      return { ...state, sessionComplete: true, isRunning: false };

    case "DISMISS_NOTIFICATION":
      return { ...state, sessionComplete: false };

    case "SET_DURATIONS": {
      const { focusDuration, breakDuration } = action.payload;
      const newFocusSeconds = focusDuration * 60;
      const newBreakSeconds = breakDuration * 60;

      // If timer is running, don't change the duration mid-session
      if (state.isRunning) {
        return {
          ...state,
          focusDuration,
          breakDuration,
        };
      }

      // Reset timer with new durations
      const resetTime = state.mode === "focus" ? newFocusSeconds : newBreakSeconds;
      return {
        ...state,
        focusDuration,
        breakDuration,
        timeLeft: resetTime,
        totalTime: resetTime,
        isRunning: false,
        sessionComplete: false,
      };
    }

    case "TOGGLE_NOTIFICATIONS":
      return {
        ...state,
        notificationsEnabled: !state.notificationsEnabled,
      };

    case "LOAD_PREFERENCES":
      const { focusDuration, breakDuration, notificationsEnabled } = action.payload;
      const loadedFocusSeconds = focusDuration * 60;
      return {
        ...state,
        focusDuration,
        breakDuration,
        notificationsEnabled,
        timeLeft: state.mode === "focus" ? loadedFocusSeconds : breakDuration * 60,
        totalTime: state.mode === "focus" ? loadedFocusSeconds : breakDuration * 60,
      };

    default:
      return state;
  }
}

export function useTimer() {
  const [state, dispatch] = useReducer(timerReducer, DEFAULT_TIMER_PREFERENCES, createInitialState);

  // Load preferences on mount
  useEffect(() => {
    const loadPreferences = async () => {
      try {
        const preferences = await getTimerPreferences();
        dispatch({ type: "LOAD_PREFERENCES", payload: preferences });
      } catch (error) {
        console.error("[useTimer] Failed to load preferences:", error);
      }
    };

    loadPreferences();
  }, []);

  // Timer tick effect
  useEffect(() => {
    if (!state.isRunning) return;

    const interval = setInterval(() => {
      dispatch({ type: "TICK" });
    }, 1000);

    return () => clearInterval(interval);
  }, [state.isRunning]);

  // Persist preferences when they change
  const updatePreferences = useCallback(
    async (focusDuration: number, breakDuration: number, notificationsEnabled: boolean) => {
      const preferences: TimerPreferences = {
        focusDuration,
        breakDuration,
        notificationsEnabled,
      };

      try {
        await setTimerPreferences(preferences);
        dispatch({
          type: "SET_DURATIONS",
          payload: { focusDuration, breakDuration },
        });
      } catch (error) {
        console.error("[useTimer] Failed to update preferences:", error);
      }
    },
    []
  );

  const toggleNotifications = useCallback(async () => {
    const newNotificationsEnabled = !state.notificationsEnabled;
    const preferences: TimerPreferences = {
      focusDuration: state.focusDuration,
      breakDuration: state.breakDuration,
      notificationsEnabled: newNotificationsEnabled,
    };

    try {
      await setTimerPreferences(preferences);
      dispatch({ type: "TOGGLE_NOTIFICATIONS" });
    } catch (error) {
      console.error("[useTimer] Failed to toggle notifications:", error);
    }
  }, [state.focusDuration, state.breakDuration, state.notificationsEnabled]);

  return {
    state,
    dispatch,
    updatePreferences,
    toggleNotifications,
  };
}

// Helper function to format seconds to MM:SS
export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${minutes.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}
