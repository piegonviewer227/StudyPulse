import { useReducer, useCallback } from "react";

export interface StudySession {
  id: string;
  subject: string;
  date: string;
  duration: number; // in minutes
}

export interface AnalyticsState {
  status: "idle" | "loading" | "error" | "success";
  totalStudyTime: number; // in hours
  sessions: StudySession[];
  error: string | null;
}

export type AnalyticsAction =
  | { type: "LOAD_START" }
  | { type: "LOAD_SUCCESS"; payload: { totalStudyTime: number; sessions: StudySession[] } }
  | { type: "LOAD_ERROR"; payload: string }
  | { type: "RESET" };

const initialState: AnalyticsState = {
  status: "idle",
  totalStudyTime: 0,
  sessions: [],
  error: null,
};

function analyticsReducer(state: AnalyticsState, action: AnalyticsAction): AnalyticsState {
  switch (action.type) {
    case "LOAD_START":
      return { ...state, status: "loading", error: null };

    case "LOAD_SUCCESS":
      return {
        ...state,
        status: "success",
        totalStudyTime: action.payload.totalStudyTime,
        sessions: action.payload.sessions,
        error: null,
      };

    case "LOAD_ERROR":
      return {
        ...state,
        status: "error",
        error: action.payload,
      };

    case "RESET":
      return initialState;

    default:
      return state;
  }
}

// Mock data for demo
const mockSessions: StudySession[] = [
  { id: "1", subject: "Mathematics", date: "Today", duration: 45 },
  { id: "2", subject: "Computer Science", date: "Yesterday", duration: 30 },
  { id: "3", subject: "Physics", date: "2 days ago", duration: 60 },
  { id: "4", subject: "Chemistry", date: "3 days ago", duration: 25 },
  { id: "5", subject: "Biology", date: "4 days ago", duration: 50 },
];

export function useAnalytics() {
  const [state, dispatch] = useReducer(analyticsReducer, initialState);

  const loadAnalytics = useCallback(async () => {
    dispatch({ type: "LOAD_START" });

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Randomly decide success or error for demo
    const shouldSucceed = Math.random() > 0.3; // 70% success rate

    if (shouldSucceed) {
      const totalMinutes = mockSessions.reduce((sum, session) => sum + session.duration, 0);
      const totalHours = (totalMinutes / 60).toFixed(1);

      dispatch({
        type: "LOAD_SUCCESS",
        payload: {
          totalStudyTime: parseFloat(totalHours),
          sessions: mockSessions,
        },
      });
    } else {
      dispatch({
        type: "LOAD_ERROR",
        payload: "Failed to load analytics. Network error.",
      });
    }
  }, []);

  const retry = useCallback(() => {
    loadAnalytics();
  }, [loadAnalytics]);

  return { state, dispatch, loadAnalytics, retry };
}
