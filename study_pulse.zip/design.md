# StudyPulse - Mobile App Interface Design

## Overview
StudyPulse is a Pomodoro Tracker app designed for students to manage focus sessions and track study progress. The app follows iOS Human Interface Guidelines with a clean, modern design optimized for portrait orientation (9:16) and one-handed usage.

## Screen List

1. **Login Screen** - Authentication entry point
2. **Timer Screen (Dashboard)** - Main Pomodoro timer with mode toggle
3. **Stats Screen (Analytics)** - Study session analytics and history
4. **Subjects Screen (Manager)** - Subject/topic management
5. **Profile Screen (Settings)** - User profile and app settings

## Primary Content and Functionality

### 1. Login Screen
- **Layout**: Centered, monochromatic design
- **Content**:
  - "StudyPulse" title (bold, prominent)
  - Username input field (placeholder: "student")
  - Password input field (masked)
  - "Log In" button
  - Hint text below button
- **Functionality**: Hardcoded credentials (student/password), loading state on submit, transition to main app

### 2. Timer Screen (Dashboard)
- **Layout**: Vertical stack with large timer display
- **Content**:
  - Mode label: "Focus Time" or "Break Time"
  - Large MM:SS countdown timer (monospace font)
  - Start/Pause button (toggles between green "Start" and red "Pause")
  - Reset button
  - Mode toggle button (Focus ↔ Break)
- **Functionality**: 
  - 25-minute Focus sessions, 5-minute Break sessions
  - Full reducer-based state management (START, PAUSE, RESET, TOGGLE_MODE)
  - In-app notification popup when timer completes
  - Visual feedback on button presses

### 3. Stats Screen (Analytics)
- **Layout**: Vertical scroll with tri-state handling
- **Content** (Success State):
  - "Total Study Time" card showing aggregated hours (e.g., 42.5 hrs)
  - List of recent study sessions with:
    - Subject name
    - Date
    - Duration in minutes
- **States**:
  - Loading: Centered spinner
  - Error: Red alert text + "Retry" button
  - Success: Analytics dashboard + session list
- **Functionality**: Interactive toggle/reload button to simulate state transitions

### 4. Subjects Screen (Manager)
- **Layout**: Input bar at top, list below
- **Content**:
  - Text input field for subject name
  - "Add" button
  - Scrollable list of subjects (pre-populated with "Mathematics", "Computer Science")
- **Functionality**: Add subjects dynamically, display in scannable list

### 5. Profile Screen (Settings)
- **Layout**: Vertical stack with user info and actions
- **Content**:
  - Circular avatar with letter ("A")
  - User name: "Alex Learner"
  - Email display
  - "Toggle Theme Mode" button (Light/Dark switch)
  - "Log Out" button
- **Functionality**: 
  - Theme toggle instantly switches all UI colors
  - Log out returns to Login Screen and resets auth state

## Key User Flows

### Authentication Flow
1. User lands on Login Screen
2. Enters username "student" and password "password"
3. Clicks "Log In"
4. Loading spinner appears
5. Transitions to Timer Screen (main dashboard)

### Pomodoro Session Flow
1. User views Timer Screen showing "Focus Time" with 25:00
2. Taps "Start" button
3. Timer counts down, button changes to red "Pause"
4. At 00:00, in-app notification pops up: "Focus session complete. Take a break!"
5. User dismisses notification
6. User taps "Toggle Mode" to switch to "Break Time" (5:00)
7. Taps "Start" again to begin break
8. Can pause/reset at any time

### Analytics Viewing Flow
1. User taps Stats tab
2. App shows loading spinner
3. After delay, displays "Total Study Time: 42.5 hrs"
4. Shows list of recent sessions (Mathematics - 45 min, Computer Science - 30 min, etc.)
5. User can tap "Reload" to simulate state transitions (Loading → Error → Success)

### Subject Management Flow
1. User taps Subjects tab
2. Sees pre-populated list: "Mathematics", "Computer Science"
3. Types "Physics" in input field
4. Taps "Add" button
5. "Physics" appears in the list

### Settings Flow
1. User taps Profile tab
2. Sees user info: "A" avatar, "Alex Learner", email
3. Taps "Toggle Theme Mode" button
4. Entire app switches from light to dark (or vice versa)
5. Taps "Log Out"
6. Returns to Login Screen

## Color Choices

### Light Palette
- **Background**: #FFFFFF (clean white)
- **Surface**: #F0F0F5 (subtle gray for cards)
- **Primary**: #4A90E2 (vibrant blue for actions)
- **Secondary**: #F5A623 (warm orange for accents)
- **Text**: #1A1A1A (dark for readability)
- **TextSecondary**: #6E6E6E (muted gray)
- **Border**: #E0E0E0 (light dividers)
- **Success**: #388E3C (green for completion)
- **Error**: #D32F2F (red for alerts)

### Dark Palette
- **Background**: #121212 (deep black)
- **Surface**: #1E1E1E (dark gray for cards)
- **Primary**: #6BA3F3 (lighter blue for visibility)
- **Secondary**: #F7BC45 (warm gold)
- **Text**: #E0E0E0 (light for readability)
- **TextSecondary**: #A0A0A0 (muted light gray)
- **Border**: #333333 (dark dividers)
- **Success**: #66BB6A (lighter green)
- **Error**: #EF5350 (lighter red)

## Typography & Spacing
- **Font**: Clean, modern sans-serif (system font stack)
- **Spacing Scale**: 4px, 8px, 16px, 24px, 32px
- **Timer Font**: Monospace for MM:SS display
- **Button Padding**: 12px horizontal, 8px vertical (minimum)
- **Card Padding**: 16px
- **Gap Between Elements**: 16px (standard), 8px (compact)

## Navigation Structure
- **Bottom Tab Navigation** (after login):
  - Timer (home icon)
  - Stats (chart icon)
  - Subjects (list icon)
  - Profile (person icon)
- **Auth State**: Separate login flow, no tab navigation visible
