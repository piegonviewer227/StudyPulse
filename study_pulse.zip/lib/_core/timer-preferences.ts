import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";
import { TimerPreferences, DEFAULT_TIMER_PREFERENCES } from "@/shared/types";

const TIMER_PREFERENCES_KEY = "studypulse_timer_preferences";

/**
 * Get timer preferences from secure storage.
 * Falls back to default preferences if not found or on error.
 */
export async function getTimerPreferences(): Promise<TimerPreferences> {
  try {
    if (Platform.OS === "web") {
      // Use localStorage for web
      const stored = window.localStorage.getItem(TIMER_PREFERENCES_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          focusDuration: parsed.focusDuration ?? DEFAULT_TIMER_PREFERENCES.focusDuration,
          breakDuration: parsed.breakDuration ?? DEFAULT_TIMER_PREFERENCES.breakDuration,
          notificationsEnabled: parsed.notificationsEnabled ?? DEFAULT_TIMER_PREFERENCES.notificationsEnabled,
        };
      }
      return DEFAULT_TIMER_PREFERENCES;
    }

    // Use SecureStore for native
    const stored = await SecureStore.getItemAsync(TIMER_PREFERENCES_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      return {
        focusDuration: parsed.focusDuration ?? DEFAULT_TIMER_PREFERENCES.focusDuration,
        breakDuration: parsed.breakDuration ?? DEFAULT_TIMER_PREFERENCES.breakDuration,
        notificationsEnabled: parsed.notificationsEnabled ?? DEFAULT_TIMER_PREFERENCES.notificationsEnabled,
      };
    }
    return DEFAULT_TIMER_PREFERENCES;
  } catch (error) {
    console.error("[TimerPreferences] Failed to get preferences:", error);
    return DEFAULT_TIMER_PREFERENCES;
  }
}

/**
 * Save timer preferences to secure storage.
 * Runs asynchronously without blocking the UI.
 */
export async function setTimerPreferences(preferences: TimerPreferences): Promise<void> {
  try {
    const serialized = JSON.stringify(preferences);

    if (Platform.OS === "web") {
      // Use localStorage for web
      window.localStorage.setItem(TIMER_PREFERENCES_KEY, serialized);
      return;
    }

    // Use SecureStore for native
    await SecureStore.setItemAsync(TIMER_PREFERENCES_KEY, serialized);
  } catch (error) {
    console.error("[TimerPreferences] Failed to set preferences:", error);
    throw error;
  }
}

/**
 * Reset timer preferences to defaults.
 */
export async function resetTimerPreferences(): Promise<void> {
  try {
    if (Platform.OS === "web") {
      window.localStorage.removeItem(TIMER_PREFERENCES_KEY);
      return;
    }

    await SecureStore.deleteItemAsync(TIMER_PREFERENCES_KEY);
  } catch (error) {
    console.error("[TimerPreferences] Failed to reset preferences:", error);
    throw error;
  }
}
