import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Switch, ActivityIndicator } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { validateDuration } from "@/shared/types";

export interface TimerConfigPanelProps {
  focusDuration: number;
  breakDuration: number;
  notificationsEnabled: boolean;
  onApplyChanges: (focusDuration: number, breakDuration: number) => Promise<void>;
  onToggleNotifications: () => Promise<void>;
  isLoading?: boolean;
}

export function TimerConfigPanel({
  focusDuration,
  breakDuration,
  notificationsEnabled,
  onApplyChanges,
  onToggleNotifications,
  isLoading = false,
}: TimerConfigPanelProps) {
  const colors = useColors();
  const [focusInput, setFocusInput] = useState(focusDuration.toString());
  const [breakInput, setBreakInput] = useState(breakDuration.toString());
  const [error, setError] = useState<string | null>(null);
  const [isApplying, setIsApplying] = useState(false);

  const handleApplyChanges = async () => {
    setError(null);

    // Validate focus duration
    const focusValidation = validateDuration(focusInput);
    if (!focusValidation.valid) {
      setError(`Focus: ${focusValidation.error}`);
      return;
    }

    // Validate break duration
    const breakValidation = validateDuration(breakInput);
    if (!breakValidation.valid) {
      setError(`Break: ${breakValidation.error}`);
      return;
    }

    setIsApplying(true);
    try {
      await onApplyChanges(focusValidation.value, breakValidation.value);
      setFocusInput(focusValidation.value.toString());
      setBreakInput(breakValidation.value.toString());
    } catch (err) {
      setError("Failed to apply changes. Please try again.");
      console.error("[TimerConfigPanel] Error applying changes:", err);
    } finally {
      setIsApplying(false);
    }
  };

  const handleToggleNotifications = async () => {
    try {
      await onToggleNotifications();
    } catch (err) {
      setError("Failed to toggle notifications.");
      console.error("[TimerConfigPanel] Error toggling notifications:", err);
    }
  };

  return (
    <View className="gap-4 rounded-2xl p-6" style={{ backgroundColor: colors.surface }}>
      {/* Header */}
      <View>
        <Text className="text-lg font-bold text-foreground">Timer Configuration</Text>
        <Text className="text-xs text-muted mt-1">Customize your focus and break durations</Text>
      </View>

      {/* Focus Duration Input */}
      <View className="gap-2">
        <Text className="text-sm font-semibold text-foreground">Focus Duration (minutes)</Text>
        <TextInput
          className="rounded-lg px-4 py-3 text-foreground border"
          style={{
            borderColor: colors.border,
            backgroundColor: colors.background,
            color: colors.foreground,
          }}
          placeholder="e.g., 25"
          placeholderTextColor={colors.muted}
          value={focusInput}
          onChangeText={setFocusInput}
          keyboardType="number-pad"
          editable={!isApplying && !isLoading}
          maxLength={3}
        />
      </View>

      {/* Break Duration Input */}
      <View className="gap-2">
        <Text className="text-sm font-semibold text-foreground">Break Duration (minutes)</Text>
        <TextInput
          className="rounded-lg px-4 py-3 text-foreground border"
          style={{
            borderColor: colors.border,
            backgroundColor: colors.background,
            color: colors.foreground,
          }}
          placeholder="e.g., 5"
          placeholderTextColor={colors.muted}
          value={breakInput}
          onChangeText={setBreakInput}
          keyboardType="number-pad"
          editable={!isApplying && !isLoading}
          maxLength={3}
        />
      </View>

      {/* Notifications Toggle */}
      <View className="flex-row justify-between items-center pt-2">
        <View>
          <Text className="text-sm font-semibold text-foreground">Push Alerts</Text>
          <Text className="text-xs text-muted mt-1">
            {notificationsEnabled ? "Enabled" : "Disabled"}
          </Text>
        </View>
        <Switch
          value={notificationsEnabled}
          onValueChange={handleToggleNotifications}
          disabled={isApplying || isLoading}
          trackColor={{ false: colors.border, true: colors.success }}
          thumbColor={notificationsEnabled ? colors.background : colors.muted}
        />
      </View>

      {/* Error Message */}
      {error && (
        <View className="rounded-lg p-3" style={{ backgroundColor: colors.error + "20" }}>
          <Text className="text-sm font-semibold" style={{ color: colors.error }}>
            {error}
          </Text>
        </View>
      )}

      {/* Apply Changes Button */}
      <TouchableOpacity
        onPress={handleApplyChanges}
        disabled={isApplying || isLoading}
        className="flex-row justify-center items-center py-3 rounded-lg gap-2"
        style={{
          backgroundColor: colors.primary,
          opacity: isApplying || isLoading ? 0.6 : 1,
        }}
      >
        {isApplying ? (
          <>
            <ActivityIndicator size="small" color={colors.background} />
            <Text className="text-base font-semibold text-background">Applying...</Text>
          </>
        ) : (
          <Text className="text-base font-semibold text-background">Apply Changes</Text>
        )}
      </TouchableOpacity>

      {/* Info Text */}
      <Text className="text-xs text-muted text-center">
        Changes apply immediately. Timer will reset to new duration.
      </Text>
    </View>
  );
}
